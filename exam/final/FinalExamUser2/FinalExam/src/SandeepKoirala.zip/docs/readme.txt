create a new workspace containing only the final project source code. no other source can be loaded in your ide during the exam
