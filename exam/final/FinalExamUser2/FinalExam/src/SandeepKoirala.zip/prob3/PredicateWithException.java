package prob3;

@FunctionalInterface
public interface PredicateWithException<T> {

    boolean test(T t) throws Exception;

    public static <T> boolean unchecked(PredicateWithException<T> pred, T value)  {
        try {
            return pred.test(value);
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

}
