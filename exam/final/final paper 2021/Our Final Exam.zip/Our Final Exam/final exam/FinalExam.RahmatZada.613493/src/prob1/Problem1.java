package prob1;

import java.util.function.BiPredicate;

//work with this lambda expression:   (Double x, Double y) -> x * y < x + y
public class Problem1 {
	// name and type of lambda goes here
	BiPredicate<Double,Double> biPredicate1= (x,y)-> isSmall(x,y);

	private static boolean isSmall(Double x, Double y) {
		return x * y < x + y;
	}


	// representing lambda as a method reference
	private BiPredicate<Double,Double> biPredicate2 = Problem1::isSmall;
	
	
	
	//representing lambda as a static nested class
	private static class MyProblem1 implements BiPredicate<Double,Double>{

		@Override
		public boolean test(Double x, Double y) {
			return x * y < x + y;
		}
	}
	
	
	//evaluate with Double inputs 2.1, 0.35
	public void evaluator() {
		System.out.println("Using input given in the startup code java file: 2.1, 0.35");
		System.out.println(biPredicate1.test(2.1,0.35));
		System.out.println(biPredicate2.test(2.1,0.35));
		System.out.println(new MyProblem1().test(2.1,0.35));

		System.out.println("Using input given in the question paper 2,7");
		System.out.println(biPredicate1.test(2.0,7.0));
		System.out.println(biPredicate2.test(2.0,7.0));
		System.out.println(new MyProblem1().test(2.0,7.0));



	}
	public static void main(String[] args) {
		Problem1 p = new Problem1();
		p.evaluator();
	}
	
	
}
