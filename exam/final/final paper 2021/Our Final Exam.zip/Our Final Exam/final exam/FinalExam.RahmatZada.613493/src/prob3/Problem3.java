package prob3;

import helperclasses.*;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
public class Problem3 {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Problem3 prog = new Problem3();
		List<LibraryMember> part= TestData.INSTANCE.getMembers();
		prog.specialBooks = TestData.INSTANCE.getAllBooks().iterator();
		LibraryMember mem = prog.detectIfWinnerDuringCheckout(part);
		System.out.println("Winner: " + (mem == null ? "none" : mem.getFirstName()));		
		
	}
	Iterator<Book> specialBooks;
	
	public LibraryMember detectIfWinnerDuringCheckout(List<LibraryMember> mems)  {		
		//fix this

		//uses the helper method checkoutHelper to try and catch any exception
		return mems.stream().filter(member -> checkoutHelper(member).getCheckoutRecordEntries().size() == 10)
				.findFirst().orElse(null);

	}

	//helper method to try/catch the exception
	private CheckoutRecord checkoutHelper(LibraryMember member){
		try{
			return member.checkout(specialBooks.next().getNextAvailableCopy(), LocalDate.now(), LocalDate.of(2015 , 6, 27));
		} catch (LibrarySystemException e) {
			throw new RuntimeException(e);
		}
	}
}
