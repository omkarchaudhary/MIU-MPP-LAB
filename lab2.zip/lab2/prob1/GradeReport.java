package mpp.lab2.prob1;

public class GradeReport {
    private Student student;
    public GradeReport(Student student){
        this.student = student;
    }

    public Student getStudent() {
        return student;
    }
}
