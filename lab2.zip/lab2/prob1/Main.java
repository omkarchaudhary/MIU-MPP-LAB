package mpp.lab2.prob1;

public class Main {
    public static void main(String[] args) {

        //case-1: create the instance of both class.
        Student student = new Student("omkar");

        //case-2: each contain the instance of other.
        Student stu = new GradeReport(student).getStudent();

        System.out.println(stu.getName());
    }
}
