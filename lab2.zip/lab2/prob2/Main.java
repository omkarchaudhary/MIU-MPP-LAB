package mpp.lab2.prob2;

public class Main {
    public static void main(String[] args) {
        //case-1: create the instance of both class.
        Order order = new Order(1);
        order.setOrderLines(new OrderLine(order));
    }
}
