package mpp.lab2.prob2;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private  int orderNum;
    private List<OrderLine> orderLines = new ArrayList<>();
    public Order(int orderNum){
        this.orderNum = orderNum;
        orderLines.add(new OrderLine(this));
    }

    public int getOrderNum() {
        return orderNum;
    }

    public List<OrderLine> getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(OrderLine orderLines) {
        this.orderLines.add(orderLines);
    }
}
