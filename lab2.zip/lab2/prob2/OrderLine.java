package mpp.lab2.prob2;

import java.util.ArrayList;
import java.util.List;

public class OrderLine {
    private Order order;
    public OrderLine(Order order){
        this.order = order;

    }

    public Order getOrder() {
        return order;
    }

}
