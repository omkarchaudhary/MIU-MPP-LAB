package mpp.lab4;

import java.time.LocalDate;

public abstract class Employee {
    String empId;
//    Employee(String  empId){
//        this.empId = empId;
//    }
    void print(){
        LocalDate now = LocalDate.now();
        System.out.println(calcCompensation(now.getMonthValue(), now.getYear()));
    }
    Paycheck calcCompensation(int month, int year){
        return new Paycheck(calcGrossPay(month, year),Tax.FICA,Tax.STATE_TAX,Tax.LOCAL_TAX,Tax.MEDICARE,Tax.SOCIAL_SECURITY);
    }
    abstract double calcGrossPay(int month, int year);
}
