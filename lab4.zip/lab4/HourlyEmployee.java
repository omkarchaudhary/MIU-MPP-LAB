package mpp.lab4;

public class HourlyEmployee extends Employee{
    private double hourlyWage;
    private double hoursPerWeek;
    private final static int NUMBER_OF_WEEKS = 4;
    HourlyEmployee(double hourlyWage, double hoursPerWeek){
        this.hourlyWage = hourlyWage;
        this.hoursPerWeek = hoursPerWeek;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public double getHoursPerWeek() {
        return hoursPerWeek;
    }

    @Override
    double calcGrossPay(int month, int year) {
        return getHoursPerWeek()*getHourlyWage()* NUMBER_OF_WEEKS;
    }
}
