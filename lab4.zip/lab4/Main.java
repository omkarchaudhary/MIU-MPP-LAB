package mpp.lab4;

public class Main {
    public static void main(String[] args) {
        Employee employee = new SalariedEmployee(8000);
        employee.calcCompensation(6,2022).getNetPay();
        employee.print();
    }
}
