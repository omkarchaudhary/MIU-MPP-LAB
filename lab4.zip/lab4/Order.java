package mpp.lab4;

import java.time.LocalDate;

public class Order {
    private int orderNo;
    private LocalDate orderDate;
    private double orderAmount;
    private CommissionedEmployee commissionedEmployee;
    Order(int orderNum, LocalDate orderDate, double orderAmount, CommissionedEmployee commissionedEmployee) {
        orderNo = orderNum;
        this.orderDate = orderDate;
        this.orderAmount = orderAmount;
        this.commissionedEmployee = commissionedEmployee;
    }
    public void setOrderNo(int s) {
        orderNo = s;
    }
    public int getOrderNo() {
        return orderNo;
    }
    public LocalDate getOrderDate() {
        return orderDate;
    }
    public double getOrderAmount() {
        return orderAmount;
    }
    public CommissionedEmployee getEmployee() {
        return commissionedEmployee;
    }
}
