package mpp.lab4;

import java.util.Date;

public class Paycheck {
    private double grossPay;
    private double fica;
    private double stateTax;
    private double localTax;
    private double medicareTax;
    private double socialSecurity;
    Paycheck(double grossPay, double fica, double stateTax, double localTax, double medicareTax, double socialSecurity){
        this.grossPay = grossPay;
        this.fica = Tax.FICA;
        this.stateTax = Tax.STATE_TAX;
        this.localTax = Tax.LOCAL_TAX;
        this.medicareTax = Tax.MEDICARE;
        this.socialSecurity = Tax.SOCIAL_SECURITY;
    }
    public void print(){
        System.out.println("The total net pay is "+ getNetPay());
    }
    @Override
    public String toString() {
         return  "The total net pay is "+ getNetPay();
    }
    public double getNetPay(){
        return grossPay -grossPay*fica - grossPay*stateTax - grossPay*localTax - grossPay*medicareTax - grossPay*socialSecurity;
    }
}
