package mpp.lab4;

public class SalariedEmployee extends Employee{
    private double salary;

    SalariedEmployee(double salary){
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    double calcGrossPay(int month, int year) {
        return getSalary();
    }
}
