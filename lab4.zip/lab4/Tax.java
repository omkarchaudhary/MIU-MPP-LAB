package mpp.lab4;

public class Tax {
    final static double FICA = 0.23 ;
    final static double STATE_TAX= 0.05;
    final static double LOCAL_TAX = 0.01;
    final  static double MEDICARE = 0.03;
    final static double SOCIAL_SECURITY= 0.075;

}
