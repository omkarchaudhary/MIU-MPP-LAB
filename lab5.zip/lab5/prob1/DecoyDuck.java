package mpp.lab5.prob1;

public class DecoyDuck extends Duck{
    public DecoyDuck() {
        setQuackBehavior(new Quack());
        setFlyBehavior(new FlyWithWings());
    }
    @Override
    public void display() {
        System.out.println("display");
    }
}
