package mpp.lab5.prob1;

public abstract class Duck {
    private FlyBehavior flyBehavior;
    private  QuackBehavior quackBehavior;

    public FlyBehavior getFlyBehavior() {
        return flyBehavior;
    }
    public QuackBehavior getQuackBehavior() {
        return quackBehavior;
    }

    public void setFlyBehavior(FlyBehavior flyBehavior) {
        this.flyBehavior = flyBehavior;
    }

    public void setQuackBehavior(QuackBehavior quackBehavior) {
        this.quackBehavior = quackBehavior;
    }

    public void quack(){
     quackBehavior.quack();
    }
    public void swim(){
        System.out.println("swimming");
    }
    public void fly(){
        flyBehavior.fly();
    }
    public abstract void display();
}
