package mpp.lab5.prob1;

public class RubberDuck extends Duck{
    public RubberDuck(){
        setQuackBehavior(new Quack());
        setFlyBehavior(new FlyWithWings());
    }
    @Override
    public void display() {
        System.out.println("display");
    }
}
