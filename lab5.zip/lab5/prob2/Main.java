package mpp.lab5.prob2;

public class Main {
    public static void main(String[] args) {
        Shape[] shapes = {new Rectangle(4, 5), new Triangle(4, 5), new Circle(4)};
        double area =0 ;
        for (Shape s : shapes) {
            area += s.computeArea();
        }
        System.out.println("Sum of areas: "+ area);
    }
}
