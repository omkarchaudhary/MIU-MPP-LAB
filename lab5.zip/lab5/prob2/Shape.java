package mpp.lab5.prob2;

public interface Shape {
    double computeArea();
}
