package mpp.lab5.prob3;

import java.time.LocalDate;

public class CustOrderFactory {
    public static  Customer createCustomer(String name){
        if(name.isEmpty()) return null;
        return new Customer(name);
    }
    public static Order newOrder(Customer customer, LocalDate orderDate){
        if(customer == null) return  null;
        Order order = new Order(orderDate);
        customer.addOrder(order);
        return order;
    }

    public static  Item createItem(String name){
        if(name.isEmpty()) return null;
        return new Item(name);
    }
}
