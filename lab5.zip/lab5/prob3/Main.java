package mpp.lab5.prob3;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Customer customer = CustOrderFactory.createCustomer("Omkar");
        Order order = CustOrderFactory.newOrder(customer, LocalDate.now());
        order.addItem("Pizza");
        System.out.println(customer.getOrders());
    }
}
