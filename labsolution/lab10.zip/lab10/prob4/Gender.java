package mpp.lab10.prob4;

public enum Gender {
	M, F
}
