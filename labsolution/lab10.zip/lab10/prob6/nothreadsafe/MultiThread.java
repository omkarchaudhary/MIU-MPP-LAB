package mpp.lab10.prob6.nothreadsafe;

public class MultiThread {
    public static void main(String[] args) {
        MultiThread multiThread = new MultiThread();
        for(int i =0 ;i<10;i++){
            multiThread.threadCall();
        }
        System.out.println("The number of elements in queue "+multiThread.queue. countElements());
    }
    final Queue queue = new Queue();
    Runnable r = () ->{
        queue.add(2);
        queue.add(3);
        queue.remove();
    };

    public void threadCall(){
        for(int i =0; i < 100; i++){
            new Thread(r).start();
        }
    }

}
