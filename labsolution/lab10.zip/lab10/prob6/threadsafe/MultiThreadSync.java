package mpp.lab10.prob6.threadsafe;

public class MultiThreadSync {
    public static void main(String[] args) {
        MultiThreadSync multiThread = new MultiThreadSync();
        for(int i =0 ;i<10;i++){
            multiThread.threadCall();
        }
        System.out.println("The number of elements in queue "+multiThread.queue. countElements());
    }
    final QueueSync queue = new QueueSync();
    Runnable r = () ->{
        queue.add(2);
        queue.add(2);
        queue.remove();
    };

    public void threadCall(){
        for(int i =0; i < 100; i++){
            new Thread(r).start();
        }
    }

}
