package mpp.lab11.prob2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SecondSmallest {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(2,8,9,3,6);
        System.out.println("The second smallest element: "+ secondElement(list));
        List<String> strList = Arrays.asList("omkar","binod","rahul");
        System.out.println("The second smallest element: "+ secondElement(strList));
    }

    public static <T> T secondElement(List<T> list){
        return list.stream()
                .sorted()
                .collect(Collectors.toList())
                .get(1);
    }
}
