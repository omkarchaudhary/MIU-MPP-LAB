package mpp.lab11.prob3;

public class CheckingAccount extends Account implements Comparable<CheckingAccount> {
	final double PENALTY = 10.00;
	public CheckingAccount(int id, double startBalance) {
		super(id, startBalance);
	}
	
	@Override
	public double getBalance() {
		return super.getBalance() - PENALTY;
	}

	@Override
	public int compareTo(CheckingAccount o) {
		return 0;
	}

}
