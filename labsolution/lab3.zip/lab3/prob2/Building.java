package mpp.lab3.prob2;

import java.util.ArrayList;
import java.util.List;

public class Building {
    private List<Apartment> apartments;
    private double maintenanceCost;

    Building(double maintenanceCost, double rent) {
        apartments = new ArrayList<>();
        this.maintenanceCost = maintenanceCost;
        addApartment(new Apartment(rent));
    }

    public void addApartment(Apartment a) {
        apartments.add(a);
    }

    public double getApartmentProfit() {
        int profit = 0;
        for (Apartment apartment : apartments) {
            profit += apartment.getRent();
        }
        return profit - maintenanceCost;
    }
}
