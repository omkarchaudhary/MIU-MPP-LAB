package mpp.lab3.prob2;

import java.util.ArrayList;
import java.util.List;

public class LandlordInfo {
    List<Building> buildings;
    LandlordInfo(){
        buildings = new ArrayList<>();
    }
    public void addBuilding(Building b){
        buildings.add(b);
    }

    public double calcProfits(){
        int profit = 0;
        for(Building building : buildings){
            profit += building.getApartmentProfit();
        }
        return profit;
    }
}
