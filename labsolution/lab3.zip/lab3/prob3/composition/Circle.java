package mpp.lab3.prob3.composition;

public class Circle {
    private Cylinder cylinder;
    private double radius;
    Circle(double radius){
        cylinder = new Cylinder(radius,radius);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public Cylinder getCylinder() {
        return cylinder;
    }

    public double computeArea(){
        return Math.PI*radius*radius;
    }

    public static void main(String[] args) {
        Circle circle = new Circle(4);
        Cylinder c = new Cylinder(4,5);
        System.out.println("The volume of cylinder "+ circle.cylinder.computeVolume());
        System.out.println("The area of circle "+circle.computeArea());
        System.out.println(c.computeVolume());
    }
}
