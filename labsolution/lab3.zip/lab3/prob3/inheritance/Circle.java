package mpp.lab3.prob3.inheritance;

public class Circle extends  Cylinder{
    private double radius;
    Circle(double radius){
        super(radius,radius);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public double computeArea(){
        return Math.PI*radius*radius;
    }

    public static void main(String[] args) {
        Cylinder c = new Cylinder(4,5);
        Circle circle = new Circle(4);
        System.out.println("The volume of cylinder "+c.computeVolume());
        System.out.println("The area of circle "+circle.computeArea());

        Cylinder cylinder = new Circle(4);
        //It doesnot make any sense to compute of volume of Cylinder with the radius only. It breaks the IS-A relation
        System.out.println(cylinder.computeVolume());
    }
}
