package mpp.lab3.prob3.inheritance;

public class Cylinder {
    private double height;
    private double radius;
    Cylinder(double height, double radius){
        this.height = height;
        this.radius = radius;
    }
    public double getHeight(){
        return height;
    }
    public double computeVolume(){
        return Math.PI*radius*radius*height;
    }

}
