package mpp.lab3.prob4;

public class Condo implements Rent {
    private double rent;
    private int numFloors;
    Condo(int numFloors){
        this.numFloors = numFloors;
        this.rent= 400;
    }

    public double getRent() {
        return rent;
    }

    public int getNumFloors() {
        return numFloors;
    }
    public double computeRent(){
        return rent*numFloors;
    }
}
