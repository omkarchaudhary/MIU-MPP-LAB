package mpp.lab3.prob4;

public class Driver {

	public static void main(String[] args) {

		Object[] objects = { new House(9000), new Condo(2), new Trailer() };
		double totalRent = Admin.computeTotalRent(objects);
		System.out.println(totalRent);

		//Using Inheritance with polymorphism
		double rentAmount =0;
		Rent[] rents = { new House(9000), new Condo(2), new Trailer() };
		for(Rent rent: rents){
			rentAmount += rent.computeRent();
		}
		System.out.println("Total rent amount using inheritance "+rentAmount);

	}
}
