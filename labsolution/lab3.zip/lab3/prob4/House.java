package mpp.lab3.prob4;

public class House implements Rent {
    private double rent;
    private double lotSize;
    House(double lotSize){
        this.lotSize = lotSize;
        this.rent=0.1;
    }

    public double getRent() {
        return rent;
    }
    public double computeRent(){
        return getRent()*lotSize;
    }
}
