package mpp.lab3.prob4;

public interface Rent {
    double computeRent();
}
