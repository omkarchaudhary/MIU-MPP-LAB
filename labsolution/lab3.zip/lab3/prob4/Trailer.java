package mpp.lab3.prob4;

public class Trailer implements Rent {
    private static final double rent = 500;

    public double getRent() {
        return rent;
    }
    public double computeRent(){
        return getRent();
    }
}
