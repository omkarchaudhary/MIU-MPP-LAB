package mpp.lab7.prob1.partE;

interface A {
    abstract void method();
}
interface  B extends A{
    void method();

}
interface  C extends A{
    void method();
}
public abstract class D implements  B, C{

}
/* Scenario 1:
if the D class is concrete class then diamond problem can be solved by making D as abstract
or implement the abstract method.
*/
interface E extends B,C{

}
/* Scenario 2:
if D is interface then there is no problem.
*/

