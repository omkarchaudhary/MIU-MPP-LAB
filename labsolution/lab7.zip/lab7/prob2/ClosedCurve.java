package mpp.lab7.prob2;

public interface ClosedCurve {	
	double computePerimeter();
}
