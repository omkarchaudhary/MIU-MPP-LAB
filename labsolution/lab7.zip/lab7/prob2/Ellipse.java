package mpp.lab7.prob2;

public class Ellipse implements ClosedCurve {
    private double semiMajorAxis;
    private double eccentricity;
    public Ellipse(double semiMajorAxis, double eccentricity) {
        semiMajorAxis = semiMajorAxis;
        eccentricity = eccentricity;
    }
    @Override
    public double computePerimeter() {
        return 4 * semiMajorAxis * eccentricity;
    }
}
