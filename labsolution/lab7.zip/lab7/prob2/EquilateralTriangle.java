package mpp.lab7.prob2;

public class EquilateralTriangle implements Polygon {
    private double side;
    EquilateralTriangle(double side){
        this.side = side;
    }

    @Override
    public double[] getSides() {
        return new double[]{side,side,side};
    }

    @Override
    public double computePerimeter() {
        return 3*side;
    }
}
