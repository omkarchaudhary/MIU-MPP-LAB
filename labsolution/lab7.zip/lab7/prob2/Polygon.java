package mpp.lab7.prob2;

public interface Polygon extends ClosedCurve{
    double[] getSides();
    default double computePerimeter(){
        double[] sides = getSides();
         double result =0;
        for(double side : sides){
            result += side;
        }
        return  result;
    }
}
