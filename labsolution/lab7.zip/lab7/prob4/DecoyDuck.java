package mpp.lab7.prob4;

public class DecoyDuck extends Duck implements FlyBehavior,QuackBehavior {
    @Override
    public void display() {
        System.out.println("display");
    }
}
