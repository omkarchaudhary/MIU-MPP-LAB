package mpp.lab7.prob4;

public class FlyWithWings implements FlyBehavior {
    @Override
    public void fly(){
        System.out.println("Flying with wings");
    }
}
