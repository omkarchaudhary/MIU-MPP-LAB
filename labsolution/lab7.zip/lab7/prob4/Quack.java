package mpp.lab7.prob4;

public class Quack implements QuackBehavior {
    @Override
    public void quack() {
        System.out.println("Quack by quacking");
    }
}
