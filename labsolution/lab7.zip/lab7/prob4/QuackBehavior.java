package mpp.lab7.prob4;

public interface QuackBehavior {
    default void quack(){
        System.out.println("Quack by quacking");
    }
}
