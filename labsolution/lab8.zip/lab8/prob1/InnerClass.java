package mpp.lab8.prob1;

import java.util.function.Supplier;

public class InnerClass {
    class MyInnerClass implements Supplier<Double>{
        @Override
        public Double get() {
            return Math.random();
        }
    }
    public static void main(String[] args) {
        Supplier<Double> val = new InnerClass().new MyInnerClass();
        System.out.println(val.get());
    }
}
