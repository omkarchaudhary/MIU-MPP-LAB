package mpp.lab8.prob1;

import java.util.function.Supplier;

public class MethodExpr {
    public static void main(String[] args) {
        Supplier<Double> val = Math::random;
        System.out.println(val.get());
    }
}
