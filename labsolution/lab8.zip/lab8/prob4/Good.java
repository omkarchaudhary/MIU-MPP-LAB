package mpp.lab8.prob4;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Good {
    public int countWords(List<String> words, char c, char d, int len) {
        return
                words.stream()   //convert list to stream
                        .filter(name -> name.contains("" + c))
                        .filter(name -> !name.contains("" + d))
                        .filter(name -> name.length() == len)
                        .collect(Collectors.toList())
                        .size();
    }




    public static void main(String[] args) {
        Good good = new Good();
        List<String> words = Arrays.asList("Bag","Cat","Tommy","Tag");
        System.out.println(good.countWords(words, 'T', 'B', 3));


    }
}
