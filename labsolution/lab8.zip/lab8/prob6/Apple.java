package mpp.lab8.prob6;

public class Apple {
    private double weight;
    Apple(double weight){
        this.weight = weight;
    }
    double getWeight(){
        return weight;
    }
}

