package mpp.lab9.part1.prob4.partA;

import java.util.stream.Stream;

public class PrimeStream {
    final Stream<Integer> primes = Stream.iterate(2,n -> nextPrime(n));

    public static int nextPrime(int num) {
        if(num < 2) return 2;
        int next = num + 1;
        while(!isPrime(next)) {
            next = next + 1;
        }
        return next;
    }

    public static boolean isPrime(int n) {
        for(int k = 2; k * k <= n; ++k) {
            if(n % k == 0) return false;
        }
        return true;

    }
}
