package mpp.lab9.part1.prob4.partB;

import mpp.lab9.part1.prob4.partA.PrimeStream;

import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) {
        printFirstNPrimes(10);
        System.out.println("====");
        printFirstNPrimes(5);
    }

    private static void printFirstNPrimes(long n){
        createStream().limit(n).forEach(System.out::println);
    }

    public static Stream<Integer> createStream(){
        PrimeStream ps = new PrimeStream();
        Stream<Integer> primes = Stream.iterate(2, n -> ps.nextPrime(n));
        return primes;
    }
}
