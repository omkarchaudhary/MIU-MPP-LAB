package mpp.lab9.part2.prob10.partA;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
