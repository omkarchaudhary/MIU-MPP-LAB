package mpp.lab9.part2.prob10.partC;

import java.util.IntSummaryStatistics;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Stream<Integer> intStream = Stream.of(15,4,3,5,9);
        IntSummaryStatistics summaryStatistics = intStream.collect(Collectors.summarizingInt(Integer::intValue));
        System.out.println("The max value is "+summaryStatistics.getMax());
        System.out.println("The min value is "+summaryStatistics.getMin());
    }
}
