package mpp.lab9.part2.prob12;

import java.util.Optional;

public class MySingletonLazy {
    private static MySingletonLazy instance = null;
    private static int count = 0;
    private MySingletonLazy(){
        count++;
    }

    public static MySingletonLazy getInstance(){
        if(instance== null){
            instance = new MySingletonLazy();
        }
        return instance;
    }

    public static MySingletonLazy getInstanceUsingOptional(){
        return Optional.ofNullable(instance)
                .map(x -> new MySingletonLazy())
                .orElse(null);
    }
    public static void main(String[] args) {
        for(int i = 0; i < 10; ++i) {
            getInstance();
        }
        System.out.println(count);
    }
}
