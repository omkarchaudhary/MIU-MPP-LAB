package mpp.lab9.part2.prob9;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class PrintSquare {
    public static void main(String[] args) {
        printSquares(4);
    }
    public static void printSquares(int num){
        IntStream intStream = IntStream.iterate(1, n -> squares(n) );
        intStream.limit(num)
                .forEach(System.out::println);
    }
    public static int squares(int n){
        return  (int) Math.pow((int)Math.sqrt(n) + 1, 2);
    }

}
