package mpp.practicetest.prob2;

import java.util.*;
import java.util.stream.Collectors;

public class Admin {
    //Returns phone numbers (in sorted order) of the Library Members who have ever checked out the specified lending item
    public static List<String> getPhoneNums(LibraryMember[] members, LendingItem item) {

        return Arrays.asList(members)
                .stream()
                .filter(data -> data.getCheckoutRecord()
                        .getCheckoutRecordEntries()
                        .stream()
                        .anyMatch(d -> d.getLendingItem().equals(item)))
                .map(LibraryMember::getPhone).sorted().collect(Collectors.toList());

    }
}
