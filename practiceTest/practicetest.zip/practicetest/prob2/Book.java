package mpp.practicetest.prob2;

import java.util.Objects;

public class Book extends LendingItem{

    private String isbn;
    private String title;
    private String authorFirstName;
    private String authorLastName;


    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthorFirstName() {
        return authorFirstName;
    }

    public String getAuthorLastName() {
        return authorLastName;
    }

    public Book(String isbn, String title, String authorFirstName, String authorLastName) {
        this.isbn = isbn;
        this.title = title;
        this.authorFirstName = authorFirstName;
        this.authorLastName = authorLastName;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null) return false;
        if(!(obj instanceof Book)) return false;
        Book book = (Book) obj;
        return book.getTitle().equals(this.getTitle())
                && book.getIsbn().equals(this.getIsbn())
                && book.getAuthorFirstName().equals(this.getAuthorFirstName())
                && book.getAuthorLastName().equals(this.getAuthorLastName());
    }


}
