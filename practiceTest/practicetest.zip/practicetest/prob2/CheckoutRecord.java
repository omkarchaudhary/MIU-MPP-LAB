package mpp.practicetest.prob2;

import java.util.ArrayList;
import java.util.List;

public class CheckoutRecord {

    private List<CheckoutRecordEntry> checkoutRecordEntries;

    public CheckoutRecord() {
        this.checkoutRecordEntries = new ArrayList<>();
    }

    public List<CheckoutRecordEntry> getCheckoutRecordEntries() {
        return checkoutRecordEntries;
    }

    public void addCheckoutEntry(CheckoutRecordEntry entry) {
        this.checkoutRecordEntries.add(entry);
    }
}
