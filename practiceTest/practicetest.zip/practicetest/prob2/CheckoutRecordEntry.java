package mpp.practicetest.prob2;

import java.time.LocalDate;

public class CheckoutRecordEntry {
    private LocalDate checkoutDate;

    private LocalDate dueDate;

    private LendingItem lendingItem;

    private ItemType itemType;

    public CheckoutRecordEntry(LendingItem lendingItem, LocalDate checkoutDate, LocalDate dueDate, ItemType itemType) {
        this.lendingItem = lendingItem;
        this.checkoutDate = checkoutDate;
        this.dueDate = dueDate;
        this.itemType = itemType;
    }

    public LocalDate getCheckoutDate() {
        return checkoutDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public ItemType getLendingItemType() {
        return itemType;
    }

    public LendingItem getLendingItem() {
        return lendingItem;
    }


}
