package mpp.practicetest.prob2;

public enum ItemType {
	BOOK, CD;
}
