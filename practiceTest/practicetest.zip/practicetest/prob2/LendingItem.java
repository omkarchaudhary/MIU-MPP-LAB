package mpp.practicetest.prob2;

public class LendingItem {


    private Integer numCopiesInLib;


    public Integer getNumCopiesInLib() {
        return numCopiesInLib;
    }

    public void setNumCopiesInLib(Integer numCopiesInLib) {
        this.numCopiesInLib = numCopiesInLib;
    }



}
