package mpp.practicetest2.innerclass;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import mpp.practicetest2.quizclasses.*;

/** SOLVE THE PROBLEMS HERE BY REPLACING LAMBDA EXPRESSIONS IN YOUR PIPELINE SOLUTIONS 
 *  WITH LOCAL INNER CLASSES
 *
 */
public class Main {
	public static void main(String[] args) {
		
		//SAMPLE: Use local inner classes to replace lambdas in your pipeline solution to 
		//this sample problem:
		//Print all Employee records for which name has length > 5 and birth year is > 1970
		
		class NameLength implements Predicate<Employee> {
			public boolean test(Employee e) {
				return e.getName().length() > 5;
			}
		}
		class BirthYear implements Predicate<Employee> {
			public boolean test(Employee e) {
				return e.getYearOfBirth() > 1970;
			}
		}

		System.out.println("Sample Query");
		List<Employee> sampleData = EmployeeTestData.getList();
		
		List<Employee> result = sampleData.stream()
							        .filter(new NameLength())
							        .filter(new BirthYear())
							        .collect(Collectors.toList());
		System.out.println(result);

				
		prob1();
		prob2();
		prob3();
	}
	
	//Transform your pipeline solution to prob1 in the pipeline package so that
	//every lambda is replaced by an instance of a
	//local inner class of the correct type
	public static void prob1() {
		//use this list 
		List<Employee> list = EmployeeTestData.getList();

//		class FilterEmployeee implements TriFunction<List<Employee>,Integer,Integer,List<Pair>>{
//			@Override
//			public List<Pair> apply(List<Employee> list, Integer s, Integer l) {
//				return list.stream()
//						.filter(emp -> emp.getSalary() > s)
//						.filter(emp -> emp.getSalary() < l)
//						.sorted(Comparator.comparing(Employee::getName).thenComparing(Employee::getSalary,Comparator.reverseOrder()))
//						.map(emp -> new Pair(emp.getName(), emp.getSalary()))
//						.collect(Collectors.toList());
//			}
//		}
//		System.out.println(new FilterEmployeee().apply(list,55000,120000));
		System.out.println("List of employee which salary > 55000 and less than 120000 ");

		class SalaryFilter implements Predicate<Employee> {
			@Override
			public boolean test(Employee employee) {
				return employee.getSalary() > 55000 && employee.getSalary() < 120000;
			}
		}
		class SortByName implements Comparator<Employee> {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		}

		class SortBySalary implements Comparator<Employee> {
			@Override
			public int compare(Employee o1, Employee o2) {
				return Integer.compare(o2.getSalary(), o1.getSalary());
			}
		}

		class MapperOfPair implements Function<Employee, Pair>{
			@Override
			public Pair apply(Employee emp) {
				return new Pair(emp.getName(), emp.getSalary());
			}
		}

		list.stream()
				.filter(new SalaryFilter())
				.sorted(new SortByName().thenComparing(new SortBySalary()))
				.map(new MapperOfPair())
				.forEach(System.out::println);
	}
	
	///Transform your pipeline solution to prob2 so that
	//every lambda is replaced by an instance of a
	//local inner class of the correct type
	public static void prob2() {
		//use this list	
		List<Transaction> list = TraderTransactTestData.getTransactions();
		class CompareYear implements Predicate<Transaction> {
			@Override
			public boolean test(Transaction transaction) {
				return transaction.getYear() >= 2011;
			}
		}
		class ComparatorTest implements Comparator<Transaction> {
			@Override
			public int compare(Transaction o1, Transaction o2) {
				return Integer.compare(o1.getValue(), o2.getValue());
			}
		}

		list.stream()
				.filter(new CompareYear())
				.sorted(new ComparatorTest())
				.forEach(System.out::println);
	}
	
	//Transform your pipeline solution to prob3 so that
	//every lambda is replaced by an instance of a
	//local inner class of the correct type
	public static void prob3() {
		//Use this list
		List<Transaction> list = TraderTransactTestData.getTransactions();
		class CityFilter implements Predicate<Transaction> {
			@Override
			public boolean test(Transaction transaction) {
				return transaction.getTrader().getCity().equals("Cambridge");
			}
		}

		class TraderNameComparator implements Comparator<Transaction> {
			@Override
			public int compare(Transaction o1, Transaction o2) {
				return o1.getTrader().getName().compareTo(o2.getTrader().getName());
			}
		}
		System.out.println("Sorting  all traders by name ");
		list.stream()
				.filter(new CityFilter())
				.sorted(new TraderNameComparator())
				.forEach(System.out::println);
	                
	}
}
