package mpp.practicetest2.lambdalib;

public interface BiFunction<S,U,R>{
    R apply(S s, U u);
}
