package mpp.practicetest2.lambdalib;

import mpp.practicetest2.quizclasses.Employee;
import mpp.practicetest2.quizclasses.Pair;
import mpp.practicetest2.quizclasses.Trader;
import mpp.practicetest2.quizclasses.Transaction;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



public class LambdaLibrary {
	public final static String IMPLEMENT = "implement!";
	
	//sample query
	public final static TriFunction<List<Employee>, Integer, Integer, List<Employee>> SAMPLE
	   = (list, namelength, year) -> list.stream()
	                                     .filter(e -> e.getName().length() > namelength)
	                                     .filter(e -> e.getYearOfBirth() > year)
	                                     .collect(Collectors.toList());
	public final static TriFunction<List<Employee>, Integer, Integer, List<Pair>> PROB1
			= (list, startSalary, lastSalary) -> list.stream()
			.filter(e -> e.getSalary() > startSalary)
			.filter(e -> e.getSalary() < lastSalary)
			.sorted(Comparator.comparing(Employee::getName).thenComparing(Employee::getSalary,Comparator.reverseOrder()))
			.map( e-> new Pair(e.getName(),e.getSalary()))
			.collect(Collectors.toList());

	public final static BiFunction<List<Transaction>, Integer, List<Transaction>> PROB2
			=(list, year) -> list.stream()
			.filter(x -> x.getYear() >= 2011)
			.sorted(Comparator.comparing(Transaction::getValue))
			.collect(Collectors.toList());
	public final static BiFunction<List<Transaction>, String, List<Transaction>> PROB3
			=(list, trader) -> list.stream()
			.filter(x -> x.getTrader().equals(trader))
			.sorted(Comparator.comparing(x->x.getTrader().getName()))
			.collect(Collectors.toList());
}
