package services.dao;

public interface IDashboard {
    public int getUserCount();
    public int getBookCount();
}
